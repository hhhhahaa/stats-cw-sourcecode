# Market simulator

Code for the following paper:

> H. Buhler, B. Horvath, T. Lyons, I. Perez Arribas and B. Wood. Generating financial markets with signatures. SSRN 3657366, 2020.
